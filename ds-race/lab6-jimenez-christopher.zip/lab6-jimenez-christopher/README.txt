Lab 6:
Included modified version of BST in the same directory of the Lab6Driver.java file. The modification included an implementation of a getRoot() method.

Regarding the balanced and unbalanced BST:
The program indicated that the height of the balanced and the unbalanced tree are the same, which may be true. this is because for randomly chosen values, the tree may be bushy.

NOTE: Please set CLASSPATH to the parent directory of of the ch03 and ch05, which would be bookFiles or wherever they are save on the machine.


To compile:
CLASSPATH must be set to the parent directory of of the ch03 and ch05 files. > export CLASSPATH .../bookFiles
>javac ../lab6-jimenez-christopher/Lab6Driver.java
OR javac/Lab6Driver.java

To RUN:
>java ../Lab6Driver